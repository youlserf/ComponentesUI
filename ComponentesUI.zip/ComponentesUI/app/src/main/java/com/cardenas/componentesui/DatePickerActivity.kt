package com.cardenas.componentesui

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class DatePickerActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_date_picker)
    }
}