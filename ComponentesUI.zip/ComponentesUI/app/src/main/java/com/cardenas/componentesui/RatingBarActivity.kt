package com.cardenas.componentesui

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class RatingBarActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_rating_bar)
    }
}